ENEC 2026 - Build a security agent in Microsoft 365 Copilot (no code)

1_Agent_Setup_copy_paste.txt  name, description, instructions, 3 starter prompts: paste them in Configure
2_Knowledge_upload_these/     8 approved security documents + 3 single-sheet workbooks: upload as Knowledge
3_Skills_optional/            2 skills (SKILL.md + .zip). Only if your Copilot shows Configure > Skills (preview)
4_Instructor_Answer_Key.txt   expected answers for the starter prompts (instructor only)

Steps: Microsoft 365 Copilot app > Create agent > Configure > fill the fields > upload knowledge > add starter prompts
> test in the test pane > Create. All data is synthetic.
