---
name: incident-brief
description: Use when someone asks for an incident brief, an incident summary, or "what is happening with incident SEC-INC-..." or with the incidents on an asset.
---
# Incident brief

## Steps
1. Find the incident(s) in ENEC_Security_Incidents: incident_id, detected_date, asset_id, incident_type, severity, status.
2. Look up the asset in ENEC_Asset_Priority_View: Asset_Criticality and Priority_Rank.
3. Use SEC-PROC-INC-001: the three triage questions and the severity guide.

## Output: exactly 5 lines per incident
What: incident type, date and status
Asset: asset_id, criticality and priority rank
Severity check: does the severity match the SEC-PROC-INC-001 guide?
First checks: the triage questions to answer next
Decision owner: the on-duty security lead with the operations shift supervisor

## Rules
- Never recommend isolating, blocking or closing as a decision. Those belong to people.
