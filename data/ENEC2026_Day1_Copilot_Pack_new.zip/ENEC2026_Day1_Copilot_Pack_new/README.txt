ENEC 2026 - AI FOR CODERS & SOFTWARE ENGINEERS
DAY 1 COPILOT PACK
Instructor: Mohammad Arshad Ahmed

WHAT IS IN THIS PACK

1_Excel_Workbooks   (open these with Copilot in Excel)
  ENEC_Asset_360_Security.xlsx     Assets with the security layer: priority view, vulnerabilities,
                                   incidents, alerts, access review, accounts, zones
  ENEC_Security_Logs.xlsx          Login logs, network flows, controller commands (large: 3,000 to 21,000 rows)
  ENEC_Security_Log_Windows.xlsx   15-minute log windows with features (large: about 23,000 rows)
  asset_360.xlsx                   Plant assets, A-001 timeline, documents, hourly sensor readings
  project_360.xlsx                 Projects, KPIs, risks, actions
  ENEC_Copilot_Exercises.xlsx      Exercises E01 to E16, with the answer to check against

2_Documents_Word    (open these with Copilot in Word or attach them in Copilot chat)
  9 documents about asset A-001 and 10 security documents.
  Versions matter: V1 is SUPERSEDED, V2 is APPROVED, V3D is DRAFT. Only V2 is authoritative.

3_Guides
  01 Prompt Engineering Guide      the seven-part structured prompt, techniques, practice prompts PE1 to PE8
  02 Copilot Exercises             E01 to E16 by role, with check answers
  03 Participant Roles Guide       a task card for your job title
  04 Copilot Prompt Pack           ten prompts that follow one investigation: The Case of Pump A-001
  Each guide is included as Word and PDF.

BEFORE THE SESSION (10 minutes)
1. Sign in to Microsoft 365 with your official ENEC account.
2. Upload the 1_Excel_Workbooks folder to OneDrive or SharePoint.
   Copilot in Excel does not work on files stored only on your computer.
3. Open a workbook from OneDrive, check that AutoSave is ON, and keep the file as .xlsx.
4. Click inside a table, then open Copilot. Every sheet is already an Excel table.

DURING THE EXERCISES
- Work on one workbook at a time.
- The log workbooks are large. Ask narrow questions and allow 30 seconds or more per answer.
- Write a weak prompt first, then a structured prompt, and compare both with the check answer.
- Note what Copilot got right, what you had to fix, and what it could not know.

RULES
All data and documents are synthetic training material. Security values are simulated.
Never paste real plant or company data into an AI tool.
Check every number before you use it. Copilot prepares evidence; a person decides.
