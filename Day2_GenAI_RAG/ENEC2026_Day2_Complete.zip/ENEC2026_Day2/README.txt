ENEC 2026 - AI for Coders and Software Engineers - Day 2
Instructor: Mohammad Arshad Ahmed | All data is synthetic training data

1_Slides
  ENEC2026_Day2_GenAI_RAG_and_SQL.pptx   30 slides, click animations, speaker notes

2_Notebooks (open in Google Colab: File > Upload notebook)
  Day2_01_OpenAI_System_Prompt_and_Gradio.ipynb   needs OpenAI key only
  Day2_02_RAG_with_LlamaIndex.ipynb               upload the 4 files in 3_Upload_Files/rag_documents
  Day2_03_SQL_EDA_and_Dashboard.ipynb             upload 3_Upload_Files/database/ENEC2026_Asset360.db

Before Lab 1 and Lab 2: add OPENAI_API_KEY in Colab Secrets (key icon, left sidebar), Notebook access ON.
If gpt-5.4-mini is not available on your key, change MODEL to "gpt-5-mini".
