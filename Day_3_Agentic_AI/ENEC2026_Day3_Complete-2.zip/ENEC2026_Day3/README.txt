ENEC 2026 - AI for Coders and Software Engineers - Day 3
Instructor: Mohammad Arshad Ahmed | All data is synthetic training data

MORNING (about 90 min) - Machine learning
  1_Slides/1_Morning_Machine_Learning.pptx            18 slides, click animations, speaker notes
  2_Notebooks/Day3_00_Machine_Learning_Decision_Tree   upload ENEC2026_Asset360.db only. NO API key needed.
  Result: the decision tree learns "vibration > 4.97 mm/s = abnormal".

AFTERNOON - Agentic AI with governance
  1_Slides/2_Afternoon_Agentic_AI.pptx                30 slides incl. governance
  2_Notebooks/Day3_01_Agent_SQL_and_RAG_with_LlamaIndex  upload all 5 files in 3_Upload_Files at once.
  Needs OPENAI_API_KEY in Colab Secrets (key icon, left), Notebook access ON.
  If gpt-5.4-mini is not available on your key, change it to "gpt-5-mini" in Step 4.

3_Upload_Files
  4 documents (.docx) + ENEC2026_Asset360.db
  optional_governance_test/: the V3 DRAFT procedure. Upload it too to see governance check 1 block it.

ADD-ON (about 30 min, optional) - Skills
  1_Slides/3_AddOn_Skills.pptx                   6 slides: instructions vs skills vs tools vs knowledge, Copilot bridge
  2_Notebooks/Day3_02_AddOn_Agent_Skills         same 5 upload files + OpenAI key. Creates 2 skills and Copilot-ready zips.
