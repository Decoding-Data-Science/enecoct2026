A-001 COPILOT AGENT - documents + Excel data + skills (Microsoft 365 Copilot)
Synthetic training data. Not for operational use.

WHAT IS IN THIS FOLDER
1_documents/        9 Word documents                 -> Knowledge
2_data/             5 Excel workbooks                -> Knowledge
3_skills/           5 skill folders, each a SKILL.md -> Skills
4_instructions.txt  paste into Instructions

THE DATA (2_data)
asset_360.xlsx                 asset health, risk, open work counts; A-001 hourly sensor data (12 months); A-001 event timeline
maintenance_history.xlsx       work orders, inspections, maintenance history for all assets (employee IDs removed)
project_360.xlsx               29 projects: status, KPIs by month, risks, actions, and which assets each project involves
ENEC_Asset_360_Security.xlsx   security posture, priority view, vulnerabilities, incidents
ENEC_Security_Logs.xlsx        raw auth logs, network flows, controller commands (large; for security questions only)

BUILD IN 6 STEPS
1. https://m365.cloud.microsoft/chat > Agents > + New agent > Skip (Configure tab).
2. Name: A-001 Reliability Assistant
   Description: Answers questions about cooling-water pump A-001 and its projects from documents and Excel data. Synthetic training data.
3. Instructions: paste 4_instructions.txt.
4. Knowledge: upload the 9 Word files and the 5 Excel files.
5. Capabilities: turn ON "Create documents, charts, and code" (code interpreter). The numbers depend on it.
6. Skills: add the 5 skills, then Create.
   The agent builder uploads each skill as a ZIP. For each folder in 3_skills: open the folder, right-click SKILL.md >
   Compress to ZIP file, rename the zip to the folder name (e.g. project-update.zip), then Skills > Add > upload it.
   SKILL.md must be at the top level of the zip. (Copilot Cowork also accepts the SKILL.md file directly.)

THE FIVE SKILLS
document-brief   "Summarise / brief me on <document>"                 -> 5-line brief (documents)
procedure-check  "Which procedure is current / newest?"                -> 4 lines: V2 current, V1 superseded, V3D draft
asset-snapshot   "A-001 health / work orders / vibration / security"   -> data table with sources (Excel)
status-report    "Write the A-001 status report"                        -> 7 headings, data + documents, class REVIEW
project-update   "Which projects involve A-001? / status of P-029"     -> one block per project (project_360.xlsx)

TEST (New chat for each) and what a correct answer contains
1. Summarise the A-001 condition monitoring report.
   -> document-brief: A001-CMR-2026-08 v1.0, APPROVED; no confirmed failure mode
2. What is the newest A-001 inspection procedure?
   -> procedure-check: V2 current; V3D is a draft, not in force
3. Give me an A-001 snapshot: health, open work orders, last 24h vibration, security priority.
   -> asset-snapshot: health 68.05, risk MEDIUM; 6 open work (5 OPEN + 1 DEFERRED; 3 high priority);
      avg vibration 5.54 mm/s (above 4.97), max 5.75, 1,440 anomaly minutes; priority 97.8 "P1 Immediate review", patch Overdue
4. Write the A-001 status report.
   -> status-report: numbers above + CMR trend 3.8 -> 6.6 mm/s, field report (rattling, wet area, source not confirmed),
      WO-2026-0817 HIGH OPEN target 28 Aug, open incident SEC-INC-0040, class REVIEW, next step qualified review using V2
5. Which projects involve A-001 and are any at risk?
   -> project-update: P-021 Data Quality Improvement 21 (ON_TRACK, 5 overdue actions),
      P-027 Supplier Performance Improvement 27 (ON_TRACK, 1 overdue),
      P-029 A-001 Cooling Water Pump Reliability Improvement (AT_RISK; top risk: continued vibration degradation may reduce availability)
6. Give me a project update for P-001.
   -> project-update: AT_RISK; latest KPI Sep 2026: actual progress 76.6% vs 96% planned; actual cost 2.21M vs 1.73M planned;
      top risk R-0001 conflicting document versions (exposure 25); 3 overdue actions
7. Who owns the reliability and escalation policy?
   -> no skill: Reliability Governance Office [REL-POL-001]

RULE TO REMEMBER
Instructions are always on. Skills load only when needed. Knowledge (documents + Excel) is what the agent reads.
Code interpreter is the agent's calculator: in Copilot it replaces the SQL tool from the notebooks.

IF SKILLS IS NOT IN YOUR TENANT
Paste the five SKILL.md texts into one Word file (A001_Playbooks.docx), upload it as Knowledge, and add to the
instructions: "When a request matches a playbook in A001_Playbooks.docx, follow its steps and output format exactly."
