---
name: procedure-check
description: Use when someone asks which procedure applies, which version is current, or for the newest or latest A-001 procedure. Checks document status before answering.
---
# Procedure check

## Steps
1. Find every version of the procedure. Note each document ID, version and status.
2. Use ONLY the APPROVED version as current guidance.
3. A DRAFT is "proposed, not in force". A SUPERSEDED version is history only.
4. Answer the question from the approved version.

## Output: exactly 4 lines
Current procedure: document ID, version, status
Says: one sentence that answers the question
Not in force: each draft or superseded version and why
Next step: confirm with the procedure owner if any status is unclear

## Rules
- A newer version number is not automatically the current one.
- Never present a draft as policy.
