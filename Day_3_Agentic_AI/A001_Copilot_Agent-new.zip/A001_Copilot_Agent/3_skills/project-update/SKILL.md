---
name: project-update
description: Use when someone asks about projects: a project status update, which projects involve A-001, projects at risk, budget or cost, top risks or overdue actions. Produces a short project update from project_360.xlsx.
---
# Project update

## Steps
1. Use code interpreter on project_360.xlsx.
2. Find the project(s): by project_id or name, or for an asset through sheet project_asset_links (filter by asset_id).
3. From sheet project_360: project_status, completion_pct, budget_usd, active_risks, overdue_actions, planned_end_date.
4. From sheet project_kpis: the LATEST kpi_month for the project; planned vs actual progress and planned vs actual cost.
5. From sheet risks: the top open risk by exposure_score (status not CLOSED), with its mitigation plan.
6. From sheet actions: count actions with status OVERDUE and list up to three with due dates.

## Output: one block per project
Project: ID, name, status
Progress: actual vs planned (latest KPI month), completion %
Cost: actual vs planned cost, budget
Top risk: description, exposure score, mitigation
Overdue actions: count, and up to three with due dates
Watch: one sentence on what needs attention

## Rules
- Numbers only from project_360.xlsx. If a sheet has no rows for the project, write "not in the data".
- Do not reveal employee IDs or manager codes.
