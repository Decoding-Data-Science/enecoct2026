---
name: status-report
description: Use when someone asks for an A-001 status report, a weekly update, a management summary or "where are we on A-001". Produces a 7-part report combining the Excel data and the documents, with a condition class from the reliability policy.
---
# A-001 status report

## Steps
1. Use code interpreter on asset_360.xlsx:
   - sheet asset_360, row A-001: health_score, risk_level, recommended_action, open_work_orders, high_priority_open_work.
   - sheet a001_sensor_hourly: sort by hour_timestamp, take the LAST 24 rows; average of avg_vibration_mm_s, maximum of max_vibration_mm_s, total anomaly_minutes. Compare the average with the learned threshold 4.97 mm/s.
2. On maintenance_history.xlsx > work_orders: list A-001 work orders with status OPEN or DEFERRED, with priority and due date.
3. On ENEC_Asset_360_Security.xlsx: Asset_Priority_View row A-001 (Priority_Score, Priority_Band, Patch_Status) and Security_Incidents for A-001 with status Open.
4. From the documents: the trend in A001-CMR-2026-08, the observation in CR-2026-0819-A001, and WO-2026-0817 (priority, status, target date).
5. Classify the condition using the classes in REL-POL-001: NORMAL, WATCH, REVIEW or URGENT REVIEW. Give the reason in one line.
6. Cite the approved procedure A001-PROC-INS-001-V2 for the inspection workflow.

## Output: seven headings, maximum 220 words
Situation
Data (each number with its file and sheet)
Document evidence (each line with its document ID)
Open work and security
Condition class (with the REL-POL-001 reason)
Gaps and uncertainty
Next human step

## Rules
- Label every number DATA and every document fact DOCUMENT.
- Never invent a number. If a value is missing, write "not in the data".
- The report does not authorise any work. A qualified person decides.
