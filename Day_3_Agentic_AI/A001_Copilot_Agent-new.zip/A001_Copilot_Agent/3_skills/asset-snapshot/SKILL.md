---
name: asset-snapshot
description: Use when someone asks for numbers about A-001 or other assets: health score, risk, work orders, inspections, maintenance cost or downtime, vibration in the last 24 hours, security priority, patch status or incidents. Produces a short data table from the Excel files.
---
# Asset snapshot

## Steps
1. Use code interpreter. Read only the sheets needed:
   - asset_360.xlsx > asset_360: health_score, risk_level, open_work_orders, high_priority_open_work
   - asset_360.xlsx > a001_sensor_hourly: last 24 rows by hour_timestamp for vibration and anomaly minutes (A-001 only)
   - maintenance_history.xlsx > work_orders, inspections, maintenance_history: individual records, filter by asset_id
   - ENEC_Asset_360_Security.xlsx > Asset_Priority_View: Priority_Score, Priority_Band, Patch_Status, Open_Security_Issues
   - ENEC_Asset_360_Security.xlsx > Security_Incidents: incidents and their status
2. Calculate exactly what was asked. Show the calculation if it involves more than one row.

## Output
A table with columns: Measure | Value | File > sheet
Then one sentence: what stands out.

## Rules
- Numbers only from the Excel files. Never estimate.
- No advice on repairs or shutdowns.
