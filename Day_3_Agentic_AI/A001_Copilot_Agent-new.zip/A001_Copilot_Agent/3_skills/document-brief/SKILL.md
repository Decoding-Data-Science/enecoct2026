---
name: document-brief
description: Use when someone asks to summarise, brief or explain one A-001 document, report, procedure, policy or work order document. Produces a 5-line brief.
---
# Document brief

## Steps
1. Find the document the user means. If it is unclear which one, ask.
2. Read its header: document ID, version, status, owner and date.
3. Pick the three points a busy engineer most needs.
4. Note what the document says it does NOT establish or cover.

## Output: exactly 5 lines
Document: ID, version, status, owner, date
Purpose: one sentence
Key points: three short points separated by semicolons
Limits: what it does not establish or cover
Related: other documents it references, by ID

## Rules
- Use only this document's content. Do not add advice.
